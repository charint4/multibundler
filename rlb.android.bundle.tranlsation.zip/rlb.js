import * as React from 'react';
import {
 View, Text, Button, AppRegistry, Image, NativeModules,
 DeviceEventEmitter, StyleSheet
} from 'react-native';
import { Images } from '../app/Assets';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import I18n from './Localizations';

const Tab = createBottomTabNavigator();

const RLBComponent = (props) => {
  const [text, setText] = React.useState('defaultText');

  React.useEffect(() => {
    setText(props.text);
  }, [props.text]);

  // React.useEffect(() => {
  //   alert(text);
  // }, []);

  return (
    <View style={{
      flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'white'
    }}
    >
      <Text>RLB App</Text>
      <Text style={styles.boldText}>`Here's the text ${text}`</Text>
      <Text>Heres the common translation text: {I18n.t('second-page')}</Text>
      <Text>Heres the local translation text: {I18n.t('local-translation')}</Text>
      <Text>Heres the local translation from zip text: {I18n.t('local-translation-from-zip')}</Text>
      <Image source={Images.uat} height={20} width={20} />
      <Button onPress={() => NativeModules.NavigationBridge.pop('text', 'BackButtonText from RLB')} title="Back" />
    </View>
  );
};

const WealthComponent = () => (
  <View>
    <Text>Wealth</Text>
  </View>
);

const styles = StyleSheet.create({
  boldText: {
    fontWeight: 'bold',
    fontSize: 30
  }
});

const BottomTabs = props => (
  <NavigationContainer>
    <Tab.Navigator
      initialRouteName="Rlb"
      screenOptions={{
        tabBarActiveTintColor: '#e91e63'
      }}
    >
      <Tab.Screen
        name="Rlb"
        component={screenProps => (<RLBComponent {...screenProps} text={props.text} />)}
      />
      <Tab.Screen name="Wealth" component={WealthComponent} />
    </Tab.Navigator>
  </NavigationContainer>
  );

AppRegistry.registerComponent('rlb', () => BottomTabs);
