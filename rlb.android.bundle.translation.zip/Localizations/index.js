import I18n from '@jenius/i18n-provider';
import idDictionary from './ID.json';
import enDictionary from './EN.json';

I18n.store({
  id: Object.assign(
    idDictionary
  ),
  en_US: Object.assign(
    enDictionary
  )
});

export default I18n;
